/*
name: PotionSaver
author: Shoffli
*/

const w = new KeyBind(gameSettings.keyBindForward());
const a = new KeyBind(gameSettings.keyBindLeft());
const s = new KeyBind(gameSettings.keyBindBack());
const d = new KeyBind(gameSettings.keyBindRight());

var isMoving = false;
var cancelStartTime = 0;
var canceling = false;

breeze.registerModule('PotionSaver', 'Allows you to keep effects while standing still.', {
    preMotion: function(event) {
        const movingNow = (w.isDown() || a.isDown() || s.isDown() || d.isDown());

        if (movingNow) {
            if (canceling) {
                const duration = ((Date.now() - cancelStartTime) / 1000).toFixed(1);
                breeze.postNotification('PotionSaver', 'Saved you ' + duration + 's');
                canceling = false;
            }
            cancelStartTime = 0;
        } else if (!cancelStartTime) {
            cancelStartTime = Date.now();
        }

        isMoving = movingNow;
    },

    packetSend: function(event) {
        const packet = event.getPacket();

            if (!isMoving && !packet.onGround) {
                isMoving = true;
            }

        if (packet instanceof C03PacketPlayer) {
            if (!isMoving && cancelStartTime && (Date.now() - cancelStartTime >= 1000)) {
                event.cancel();

                if (!canceling) {
                    canceling = true;
                    breeze.postNotification('PotionSaver', 'Saving your effects');
                }
            }
        }
    }
});