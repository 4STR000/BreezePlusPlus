/*
name: Jetpack
author: Shoffli
*/

const space = new KeyBind(gameSettings.keyBindJump());

breeze.registerModule('Jetpack', 'Makes you a rocket.', {
    mode: new ModeSetting('Mode', 'Jetpack mode.', 'Normal', ['Normal', 'Verus']),
    speed: new DoubleSetting('Speed', 'The speed used.', 1, 0.1, 5),

    motion: function(event) {
        const player = mc.getPlayer();
        if (!player || mc.isGuiOpen()) return;

        if (this.mode.is('Normal')) {
            if (space.isDown()) {
                event.setY(this.speed.getValue());
            }
        } else if (this.mode.is('Verus')) {
            if (space.isDown()) {
                const motionY = this.speed.getValue();
                event.setY(motionY);
            }

            if (event.getY() > 0) {
                const heldItem = new ItemStack(166, 1);
                const pos = new BlockPos(player.getX(), player.getY() - 1, player.getZ());
                const facing = 1;
                const hitVec = new Vec3(0.5, 0.5, 0.5);

                const packet = new C08PacketBlockPlacement(pos, facing, heldItem, hitVec);
                breeze.sendPacket(packet, false);
            }
        }
    }
});