/*
name: Fly
author: Shoffli
*/

const w = new KeyBind(gameSettings.keyBindForward());
const a = new KeyBind(gameSettings.keyBindLeft());
const s = new KeyBind(gameSettings.keyBindBack());
const d = new KeyBind(gameSettings.keyBindRight());
const shift = new KeyBind(gameSettings.keyBindSneak());
const space = new KeyBind(gameSettings.keyBindJump());

function degrees_to_radians(degrees) {
  return degrees * (Math.PI / 180);
}

var packets = [];
var falling = false;
var fallDistance = 0;
const placeTimer = new Timer();

breeze.registerRotationModule('Fly', 'Allows you to fly.', 100, {
  mode: new ModeSetting('Mode', 'The mode to use.', 'Normal', ['Normal', 'PvPGym', 'Verus', 'OldVulcanGlide']),
  hspeed: new DoubleSetting('HorizontalSpeed', 'The speed used horizontally.', 1, 0, 10),
  vspeed: new DoubleSetting('VerticalSpeed', 'The speed used vertically.', 1, 0, 10),

motion: function (event) {
  const player = mc.getPlayer();
  if (!player) return;

  const yaw = player.getLastYaw();
  const deg = yaw % 360;

  if (this.mode.is('OldVulcanGlide')) {
    if (!player.onGround() && event.getY() < 0) {
      falling = true;
      fallDistance += Math.abs(event.getY());
    }

    if (player.onGround()) {
      falling = false;
      fallDistance = 0;
    }

    if (falling && fallDistance > 0) {
      var motionY = (player.getTicksExisted() % 2 === 0) ? -0.155 : -0.1;
      event.setY(motionY);
    }
    return;
  }

  if (this.mode.is('Verus')) {
    if (space.isDown()) {
      event.setY(0.5);
    } else if (shift.isDown()) {
      event.setY(-0.5);
    } else {
      event.setY(0);
    }

    var speed = 0.36;

    var fb = 0, strafe = 0;

    if (w.isDown() && !mc.isGuiOpen()) fb += 1;
    if (s.isDown() && !mc.isGuiOpen()) fb -= 1;
    if (a.isDown() && !mc.isGuiOpen()) strafe -= 1;
    if (d.isDown() && !mc.isGuiOpen()) strafe += 1;

    if (fb === 0 && strafe === 0) {
      event.setX(0);
      event.setZ(0);
    } else if (fb === 1 && strafe === 0) {
      event.setX(-Math.sin(degrees_to_radians(deg)) * speed);
      event.setZ(Math.cos(degrees_to_radians(deg)) * speed);
    } else if (fb === -1 && strafe === 0) {
      event.setX(-Math.sin(degrees_to_radians(deg + 180)) * speed);
      event.setZ(Math.cos(degrees_to_radians(deg + 180)) * speed);
    } else if (fb === 1 && strafe === 1) {
      event.setX(-Math.sin(degrees_to_radians(deg + 45)) * speed);
      event.setZ(Math.cos(degrees_to_radians(deg + 45)) * speed);
    } else if (fb === 1 && strafe === -1) {
      event.setX(-Math.sin(degrees_to_radians(deg - 45)) * speed);
      event.setZ(Math.cos(degrees_to_radians(deg - 45)) * speed);
    } else if (fb === -1 && strafe === 1) {
      event.setX(-Math.sin(degrees_to_radians(deg + 135)) * speed);
      event.setZ(Math.cos(degrees_to_radians(deg + 135)) * speed);
    } else if (fb === -1 && strafe === -1) {
      event.setX(-Math.sin(degrees_to_radians(deg + 225)) * speed);
      event.setZ(Math.cos(degrees_to_radians(deg + 225)) * speed);
    } else if (fb === 0 && strafe === 1) {
      event.setX(-Math.sin(degrees_to_radians(deg + 90)) * speed);
      event.setZ(Math.cos(degrees_to_radians(deg + 90)) * speed);
    } else if (fb === 0 && strafe === -1) {
      event.setX(-Math.sin(degrees_to_radians(deg - 90)) * speed);
      event.setZ(Math.cos(degrees_to_radians(deg - 90)) * speed);
    }

    return;
  }

  if (this.mode.is('Normal') || this.mode.is('PvPGym')) {
    var hspeed = this.hspeed.getValue() * 0.2805;
    var vspeed = this.vspeed.getValue() * 0.2805;
    var fb = 0, strafe = 0, up = 0;

    if (w.isDown() && !mc.isGuiOpen()) fb += 1;
    if (s.isDown() && !mc.isGuiOpen()) fb -= 1;
    if (a.isDown() && !mc.isGuiOpen()) strafe -= 1;
    if (d.isDown() && !mc.isGuiOpen()) strafe += 1;
    if (space.isDown() && !mc.isGuiOpen()) up += 1;
    if (shift.isDown() && !mc.isGuiOpen()) up -= 1;

    if (fb === 0 && strafe === 0) {
      event.setX(0);
      event.setZ(0);
    } else if (fb === 1 && strafe === 0) {
      event.setX(-Math.sin(degrees_to_radians(deg)) * hspeed);
      event.setZ(Math.cos(degrees_to_radians(deg)) * hspeed);
    } else if (fb === -1 && strafe === 0) {
      event.setX(-Math.sin(degrees_to_radians(deg + 180)) * hspeed);
      event.setZ(Math.cos(degrees_to_radians(deg + 180)) * hspeed);
    } else if (fb === 1 && strafe === 1) {
      event.setX(-Math.sin(degrees_to_radians(deg + 45)) * hspeed);
      event.setZ(Math.cos(degrees_to_radians(deg + 45)) * hspeed);
    } else if (fb === 1 && strafe === -1) {
      event.setX(-Math.sin(degrees_to_radians(deg - 45)) * hspeed);
      event.setZ(Math.cos(degrees_to_radians(deg - 45)) * hspeed);
    } else if (fb === -1 && strafe === 1) {
      event.setX(-Math.sin(degrees_to_radians(deg + 135)) * hspeed);
      event.setZ(Math.cos(degrees_to_radians(deg + 135)) * hspeed);
    } else if (fb === -1 && strafe === -1) {
      event.setX(-Math.sin(degrees_to_radians(deg + 225)) * hspeed);
      event.setZ(Math.cos(degrees_to_radians(deg + 225)) * hspeed);
    } else if (fb === 0 && strafe === 1) {
      event.setX(-Math.sin(degrees_to_radians(deg + 90)) * hspeed);
      event.setZ(Math.cos(degrees_to_radians(deg + 90)) * hspeed);
    } else if (fb === 0 && strafe === -1) {
      event.setX(-Math.sin(degrees_to_radians(deg - 90)) * hspeed);
      event.setZ(Math.cos(degrees_to_radians(deg - 90)) * hspeed);
    }

    if (up === 1) event.setY(vspeed);
    else if (up === -1) event.setY(-vspeed);
    else event.setY(0);
  }
},

  tick: function () {
    if (this.mode.is('Verus')) {
      const player = mc.getPlayer();
      if (!player) return;

      const heldItem = new ItemStack(166, 1);
      const pos = new BlockPos(player.getX(), player.getY() - 1, player.getZ());
      const facing = 1;
      const hitVec = new Vec3(0.5, 0.5, 0.5);

      const packet = new C08PacketBlockPlacement(pos, facing, heldItem, hitVec);
      breeze.sendPacket(packet, false);
      placeTimer.reset();
    }

    var hideSpeedSettings = this.mode.is('Verus') || this.mode.is('OldVulcanGlide');
    this.hspeed.setHidden(hideSpeedSettings);
    this.vspeed.setHidden(hideSpeedSettings);

    if (this.mode.is('PvPGym')) {
      mc.setTimerSpeed(0.2);
    }
  },

  packetSend: function (event) {
    if (this.mode.is('PvPGym')) {
      packets.push(event.getPacket());
      event.cancel();
    }
  },

  rotate: function (rotation) {
    if (!this.mode.is('Verus')) return;

      rotation.setInstant(true);
      rotation.setLegitWalk(false);

      rotation.rotate(0, 0, 0);
  },

  disable: function () {
    falling = false;
    fallDistance = 0;

    if (this.mode.is('Normal') || this.mode.is('PvPGym')) {
      const player = mc.getPlayer();
      player.setMotion(0, player.getMotionY(), 0);
      packets.forEach(function(p) {
        breeze.sendPacket(p, false);
      });
      packets = [];
      mc.setTimerSpeed(1);
    }
  }
});