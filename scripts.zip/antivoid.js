/*
name: AntiVoid
author: Shoffli
*/

var falling = false;
var fallDistance = 0;
var notificationSent = false;

breeze.registerModule('AntiVoid', 'Prevents falling into the void.', {
    isOverVoid: false,
    cachedPackets: [],

    packetSend: function(event) {
        const packet = event.getPacket();

        if (this.isOverVoid && fallDistance >= 5 && fallDistance < 10) {
            this.cachedPackets.push(packet);
            event.cancel();

            if (!notificationSent) {
                breeze.postNotification('AntiVoid', 'Cancelling packets...');
                notificationSent = true;
            }
        }
    },

    motion: function(event) {
        const player = mc.getPlayer();
        if (player) {
            const feetPos = player.getPosition();
            const trace = world.rayTraceBlocks(
                feetPos,
                new Vec3(feetPos.getX(), feetPos.getY() - 500, feetPos.getZ()),
                true,
                true,
                false
            );

            if (!trace) {
                this.isOverVoid = true;
            } else {
                this.isOverVoid = false;
                fallDistance = 0;
            }

            if (event.getY() < 0) {
                if (this.isOverVoid) {
                    fallDistance += Math.abs(event.getY());
                }
            }

            if (this.isOverVoid && fallDistance < 10 && event.getY() === 0) {
                this.sendCachedPackets();
            }

            if (fallDistance >= 10) {
                this.clearCachedPackets();
            }
        }
    },

    tick: function(event) {
        const player = mc.getPlayer();
        if (player && player.onGround()) {
            fallDistance = 0;
            this.isOverVoid = false;
            this.sendCachedPackets();
            notificationSent = false;
        }
    },

    sendCachedPackets: function() {
        this.cachedPackets.forEach(packet => {
            breeze.sendPacket(packet, false);
        });
        this.cachedPackets = [];
    },

    clearCachedPackets: function() {
        this.cachedPackets = [];
    },

    disable: function() {
        this.isOverVoid = false;
        fallDistance = 0;
        this.clearCachedPackets();
        notificationSent = false;
    }
});