/*
name: NoSlow
author: Shoffli
*/

breeze.registerModule('NoSlow', 'Stops you from slowing down when using items.', {
    mode: new ModeSetting('Mode', 'The mode to use.', 'Normal', ['Normal', 'NCP (Consume)']),
    advantage: new DoubleSetting('Advantage', 'How much you get affected.', 1, 0.01, 1),

    swordIDs: [267, 268, 272, 276, 283],

    preMotion: function(event) {
        if (mc.getPlayer().isUsingItem()) {
            var currentSlot = inventory.currentSlot();
            var heldItem = inventory.getStackInSlot(currentSlot);

            if (this.mode.is('NCP (Consume)') && heldItem && this.swordIDs.includes(heldItem.getItemId())) {
                return;
            }
            
            if (mc.getPlayer().isSneaking()) {
                if (event.getForward() > 0) event.setForward(this.advantage.getValue() * 0.8 * 0.294 + 0.2 * 0.294);
                if (event.getForward() < 0) event.setForward(this.advantage.getValue() * 0.8 * -0.294 - 0.2 * 0.294);
                if (event.getStrafe() > 0) event.setStrafe(this.advantage.getValue() * 0.8 * 0.294 + 0.2 * 0.294);
                if (event.getStrafe() < 0) event.setStrafe(this.advantage.getValue() * 0.8 * -0.294 - 0.2 * 0.294);
            } else {
                if (event.getForward() > 0) event.setForward(this.advantage.getValue() * 0.8 * 0.98 + 0.2 * 0.98);
                if (event.getForward() < 0) event.setForward(this.advantage.getValue() * 0.8 * -0.98 - 0.2 * 0.98);
                if (event.getStrafe() > 0) event.setStrafe(this.advantage.getValue() * 0.8 * 0.98 + 0.2 * 0.98);
                if (event.getStrafe() < 0) event.setStrafe(this.advantage.getValue() * 0.8 * -0.98 - 0.2 * 0.98);
            }
        }
    },

    tick: function(event) {
        if (this.mode.is('NCP (Consume)') && mc.getPlayer().isUsingItem()) {
            var currentSlot = inventory.currentSlot();
            var heldItem = inventory.getStackInSlot(currentSlot);

            if (!heldItem || !this.swordIDs.includes(heldItem.getItemId())) {
                breeze.sendPacket(new C08PacketBlockPlacement(
                    new BlockPos(Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY), 
                    1, 
                    new ItemStack(1, 0),
                    new Vec3(0, 0, 0)
                ), false);
            }
        }
    }
});