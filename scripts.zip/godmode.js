/*
name: GodMode
author: Shoffli
*/

breeze.registerModule('GodMode', 'Makes you invulnerable to damage.', {
    packetSend: function(event) {
        const packet = event.getPacket();

        if (packet instanceof C03PacketPlayer) {
            packet.onGround = true;
        }
    },

    packetReceive: function(event) {
        const player = mc.getPlayer();
        const packet = event.getPacket();

        if (packet instanceof S12PacketEntityVelocity &&
            packet.getEntityID() === player.getEntityId()) {
            event.cancel();
        }

        if (packet instanceof S19PacketEntityStatus &&
            packet.getEntity().getEntityId() === player.getEntityId()) {
            event.cancel();
        }
    },

    tick: function() {
        const player = mc.getPlayer();

        if (player.getHealth() < player.getMaxHealth()) {
            var i = 0;
            while (i < 100) {
                breeze.sendPacket(new C03PacketPlayer(true), false);
                i++;
            }
        }
    }
});