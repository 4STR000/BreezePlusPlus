/*
name: NoFall
author: Shoffli
*/

var falling = false;
var fallDistance = 0;
var timerActive = false;

breeze.registerModule('NoFall', 'Makes you take no fall damage.', {
    mode: new ModeSetting('Mode', 'The mode to use.', 'Spoof', ['Spoof', 'Spam', 'NoGround', 'Reduce', 'Watchdog', 'Vulcan']),
    voidCheck: new BooleanSetting('VoidCheck', 'Do not activate NoFall if falling into the void.', true),

    packetSend: function(event) {
        const packet = event.getPacket();

        if (this.mode.is('Spoof') && packet instanceof C03PacketPlayer && falling && fallDistance >= 3) {
            packet.onGround = true;
        } else if (this.mode.is('NoGround') && packet instanceof C03PacketPlayer) {
            packet.onGround = false;
        } else if (this.mode.is('Vulcan') && packet instanceof C03PacketPlayer && falling && fallDistance >= 3.5) {
            const originalY = packet.getPositionY();
            packet.setPosition(packet.getPositionX(), originalY - 0.07, packet.getPositionZ());
        } else if (this.mode.is('Reduce') && packet instanceof C03PacketPlayer) {
            if (falling && fallDistance > 3.5) {
                fallDistance = 0;
                mc.setTimerSpeed(0.75);
                breeze.sendPacket(new C03PacketPlayer(true), true);
                timerActive = true;
            }
        } else if (this.mode.is('Watchdog') && packet instanceof C03PacketPlayer) {
            if (falling && fallDistance > 3) {
                fallDistance = 0;
                mc.setTimerSpeed(0.75);
                breeze.sendPacket(new C03PacketPlayer(true), true);
                timerActive = true;
            }
        }
    },

    motion: function(event) {
        const player = mc.getPlayer();
        if (player && !player.onGround() && event.getY() < 0) {
            if (this.voidCheck.getValue()) {
                const feetPos = player.getPosition();
                const trace = world.rayTraceBlocks(feetPos, new Vec3(feetPos.getX(), feetPos.getY() - 500, feetPos.getZ()), true, true, false);
                if (!trace) {
                    falling = false;
                    return;
                }
            }
            falling = true;
        }

        if (falling) {
            fallDistance += Math.abs(event.getY());
        }

        if (falling && fallDistance >= 1.75 && this.mode.is('Spam')) {
            breeze.sendPacket(new C03PacketPlayer(true), false);
        }
    },

    tick: function(event) {
        const player = mc.getPlayer();
        if (player && player.onGround()) {
            fallDistance = 0;
            falling = false;
            if (timerActive) {
                mc.setTimerSpeed(1);
                timerActive = false;
            }
        }

        if (this.mode.is('NoGround')) {
            this.voidCheck.setHidden(true);
        } else {
            this.voidCheck.setHidden(false);
        }
    },

    disable: function() {
        falling = false;
        fallDistance = 0;
        if (timerActive) {
            mc.setTimerSpeed(1);
            timerActive = false;
        }
    }
});