/*
name: FastClimb
author: Shoffli
*/

const space = new KeyBind(gameSettings.keyBindJump());

breeze.registerModule('FastClimb', 'Makes you climb faster.', {
    climbTimer: new DoubleSetting('ClimbTimer', 'Timer speed while climbing.', 1.2, 1, 10),
    useLaddersAndVines: new BooleanSetting('Ladders/Vines', 'Enable for ladders and vines.', true),
    useStairs: new BooleanSetting('Stairs', 'Enable for stairs.', true),

    tick: function(event) {
        var player = mc.getPlayer();
        if (!player) return;

        var pos = new BlockPos(player.getX(), player.getY(), player.getZ());
        var posBelow = pos.down();

        const LADDER_ID = 65;
        const VINE_ID = 106;

        const STAIR_IDS = [
            53,
            67,
            108,
            109,
            114,
            128,
            134,
            135,
            136,
            156,
            163,
            164,
            180
        ];

        var applyClimbBoost = false;

        if (this.useLaddersAndVines.getValue()) {
            const blockId = pos.getBlockId();
            if ((blockId === LADDER_ID || blockId === VINE_ID) && player.getMotionY() > 0 && !space.isDown()) {
                applyClimbBoost = true;
            }
        }

        if (this.useStairs.getValue()) {
            const stairHere = STAIR_IDS.includes(pos.getBlockId());
            const stairBelow = STAIR_IDS.includes(posBelow.getBlockId());
            const movingHorizontally = player.getMotionX() !== 0 || player.getMotionZ() !== 0;

            if ((stairHere || stairBelow) && movingHorizontally) {
                applyClimbBoost = true;
            }
        }

        mc.setTimerSpeed(applyClimbBoost ? this.climbTimer.getValue() : 1);
    },

    disable: function() {
        mc.setTimerSpeed(1);
    }
});