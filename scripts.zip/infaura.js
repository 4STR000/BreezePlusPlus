/*
name: InfAura
author: Shoffli
*/

breeze.registerModule('InfAura', 'Basically BlatantAura with infinite reach.', {
  delay: new IntSetting('Delay', 'The delay between attack cycles.', 50, 0, 1000),
  lastAttackTime: 0,

  path: [],
  reversing: false,
  target: null,
  originalPos: null,

  tick: function () {
    var player = mc.getPlayer();
    if (!player || this.path.length > 0) return;

    var currentTime = new Date().getTime();
    if (currentTime - this.lastAttackTime < this.delay.getValue()) return;

    var entities = world.getPlayers();
    var closest = null;
    var closestDist = 9999;
    var i = 0;

    while (i < entities.length) {
      var e = entities[i];
      if (e.getEntityId() !== player.getEntityId()) {
        var dist = player.getDistanceToEntity(e);
        if (dist < closestDist) {
          closest = e;
          closestDist = dist;
        }
      }
      i++;
    }

    if (!closest) return;

    this.target = closest;
    this.originalPos = player.getPosition();
    var to = this.target.getPosition();

    this.path = this.generatePath(this.originalPos, to);
    this.reversing = false;
    this.renderPath = this.path.slice();
    this.doTeleport();
    this.lastAttackTime = currentTime;
  },

  generatePath: function (from, to) {
    var path = [];
    var dx = to.getX() - from.getX();
    var dy = to.getY() - from.getY();
    var dz = to.getZ() - from.getZ();
    var dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
    var steps = Math.ceil(dist / 6);

    var stepX = dx / steps;
    var stepY = dy / steps;
    var stepZ = dz / steps;

    var x = from.getX();
    var y = from.getY();
    var z = from.getZ();
    var i = 0;

    while (i < steps) {
      x += stepX;
      y += stepY;
      z += stepZ;
      path.push(new Vec3(x, y, z));
      i++;
    }

    path.push(to);
    return path;
  },

  doTeleport: function () {
    var player = mc.getPlayer();
    if (!player || this.path.length === 0) return;

    var i = 0;
    while (i < this.path.length) {
      var pos = this.path[i];
      breeze.sendPacket(new C04PacketPlayerPosition(pos.getX(), pos.getY(), pos.getZ(), true), false);
      i++;
    }

    if (this.target && player.getDistanceToEntity(this.target) <= 400) {
      player.swingItem();
      playerController.attackEntity(this.target);
    }

    var j = this.path.length - 1;
    this.reversing = true;

    while (j >= 0) {
      var back = this.path[j];
      breeze.sendPacket(new C04PacketPlayerPosition(back.getX(), back.getY(), back.getZ(), true), false);
      j--;
    }

    this.path = [];
    this.reversing = false;
    this.target = null;
    this.originalPos = null;
  },

  disable: function () {
    this.path = [];
    this.reversing = false;
    this.target = null;
    this.originalPos = null;
    this.renderPath = [];
  }
});