/*
name: InstantUse
author: Shoffli
*/

// USING ALT CUS OF A BUG IN THE API
const r = new KeyBind(56);

breeze.registerModule('InstantUse', 'Allows you to use items instantly.', {
    packets: new IntSetting('Packets', 'The amount of packets sent per tick.', 40, 1, 100),

    sentPacket: false,

    tick: function(event) {
        const currentItem = inventory.getStackInSlot(inventory.currentSlot());

        if (!currentItem) return;

        const isHoldingBow = currentItem.getItemId() == 261;

        const isFoodItem = currentItem.getItemId() === 393 || // Baked Potato
                           currentItem.getItemId() === 297 || // Bread
                           currentItem.getItemId() === 354 || // Cake
                           currentItem.getItemId() === 364 || // Steak
                           currentItem.getItemId() === 366 || // Cooked Chicken
                           currentItem.getItemId() === 350 || // Cooked Fish
                           currentItem.getItemId() === 350 || // Cooked Salmon
                           currentItem.getItemId() === 424 || // Cooked Mutton
                           currentItem.getItemId() === 320 || // Cooked Porkchop
                           currentItem.getItemId() === 412 || // Cooked Rabbit
                           currentItem.getItemId() === 357 || // Cookie
                           currentItem.getItemId() === 322 || // Golden Apple
                           currentItem.getItemId() === 322 || // Enchanted Golden Apple
                           currentItem.getItemId() === 396 || // Golden Carrot
                           currentItem.getItemId() === 362 || // Melon Seeds
                           currentItem.getItemId() === 335 || // Milk Bucket
                           currentItem.getItemId() === 282 || // Mushroom Stew
                           currentItem.getItemId() === 400 || // Pumpkin Pie
                           currentItem.getItemId() === 361 || // Pumpkin Seeds
                           currentItem.getItemId() === 413 || // Rabbit Stew
                           currentItem.getItemId() === 353;   // Sugar

        const isPotion = currentItem.getItemId() == 373;

        if (isFoodItem || isPotion || isHoldingBow) {
            if (r.isDown() && !mc.isGuiOpen()) {
                playerController.sendUseItem();
                for (var i = 0; i < this.packets.getValue(); i++) {
                    breeze.sendPacket(new C03PacketPlayer(false), false);
                }

                if (isFoodItem) {
                    breeze.postNotification('InstantUse', 'Tried to use food');
                }

                if (isPotion) {
                    breeze.postNotification('InstantUse', 'Tried to use potion');
                }

                if (isHoldingBow) {
                    playerController.onStoppedUsingItem();
                    breeze.postNotification('InstantUse', 'Tried to shoot');
                }
            }
        } else {
            if (!mc.getPlayer().isUsingItem()) {
            }
        }
    }
});
