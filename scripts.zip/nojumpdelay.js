/*
name: NoJumpDelay
author: Shoffli
*/

var space = new KeyBind(gameSettings.keyBindJump())
var w = new KeyBind(gameSettings.keyBindForward())

breeze.registerModule('NoJumpDelay', 'Removes the jump delay.', {
    tick: function(event) {
        var player = mc.getPlayer();

        if (space.isDown() && !w.isDown() && player.onGround() && !mc.isGuiOpen()) {
            player.jump();
        }
    }
});