/*
name: Tower
author: Shoffli
*/

const space = new KeyBind(gameSettings.keyBindJump());

breeze.registerModule('Tower', 'Allows you to tower up faster.', {

  motion: function (event) {
    const player = mc.getPlayer();
    if (!player || !space.isDown() || mc.isGuiOpen()) return;

    if (player.onGround()) {
      event.setY(0.41999998688698);
      this.shouldPlacePause = false;
    } else if (this.shouldPlacePause) {
      if (player.getMotionY() > -0.0784000015258789) {
        event.setY(-0.0784000015258789);
      }
      this.shouldPlacePause = false;
    }
    event.setX(event.getX() * 0.8);
    event.setZ(event.getZ() * 0.8);
  },

  packetSend: function (event) {
    const player = mc.getPlayer();
    const packet = event.getPacket();

    if (packet instanceof C08PacketBlockPlacement) {
      const pos = packet.getPosition();
      const blockBelow = new BlockPos(
        player.getX(),
        (player.getY() - 1.4),
        player.getZ()
      );

      if (pos.equals(blockBelow)) {
        this.shouldPlacePause = true;
      }
    }
  }
});