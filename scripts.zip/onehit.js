/*
name: OneHit
author: Shoffli
*/

breeze.registerModule('OneHit', 'Allows you to kill players with one hit in combo.', {
    multiplier: new IntSetting('Multiplier', 'How many times to attack.', 100, 2, 500),
    swing: new BooleanSetting('Swing', 'Makes the module a bit more legit.', true),

    packetSend: function(event) {
        const packet = event.getPacket();

        if (packet instanceof C02PacketUseEntity && String(packet.getAction()) === "ATTACK") {
            const entity = packet.getEntity();
            if (entity) {
                var count = 1;
                while (count < this.multiplier.getValue()) {
                    if (this.swing.getValue()) {
                        breeze.sendPacket(new C0APacketAnimation(), false);
                    }
                    breeze.sendPacket(new C02PacketUseEntity(entity, "ATTACK", null), false);
                    count++;
                }
                breeze.postNotification('OneHit', 'Sent attacks');
            }
        }
    }
});