/*
name: Disabler
author: Shoffli
*/

const timer = new Timer();

breeze.registerModule('Disabler', 'Disables AntiCheats.', {
    noSprint: new BooleanSetting('NoSprint', 'Disables sprinting serversided.', false),
    ghostMode: new BooleanSetting('Ghost', 'Cancels Lagback.', false),
    positionMode: new BooleanSetting('Position', 'Puts you up.', false),
    placeMode: new BooleanSetting('Place', 'Disables some placement stuff.', false),
    karhu: new BooleanSetting('Karhu', 'Disables almost all Karhu movement and combat checks.', false),
    vulcanScaffold: new BooleanSetting('VulcanScaffold (USE NOSPRINT)', 'Disables the Vulcan limit check.', false),
    BlocksMCVelocity: new BooleanSetting('BlocksMCVelocity', 'Disables Velocity checks on BlocksMC.', false),
    minelandOld: new BooleanSetting('MinelandOld (BIND)', 'Disables the Mineland AntiCheat.', false),

    lastOnGround: true,

    tick: function(event) {
        const player = mc.getPlayer();
        if (!player) return;

        if (this.vulcanScaffold.getValue()) {
            if (timer.hasPassed(1500)) {
                breeze.sendPacket(new C0BPacketEntityAction(player, "START_SNEAKING"), false);
                breeze.sendPacket(new C0BPacketEntityAction(player, "STOP_SNEAKING"), false);
                timer.reset();
            }
        }

        if (this.karhu.getValue()) {
            const x = player.getX();
            const y = player.getY();
            const z = player.getZ();
            breeze.sendPacket(new C06PacketPlayerPosLook(x, y, z, player.getYaw(), player.getPitch(), false), false);
        }
    },

    packetSend: function(event) {
        const packet = event.getPacket();

        if (this.minelandOld.getValue()) {
            if (packet instanceof C0FPacketConfirmTransaction) {
                event.cancel();
            } else if (packet instanceof C03PacketPlayer) {
                if (!(packet instanceof C04PacketPlayerPosition) &&
                    !(packet instanceof C05PacketPlayerLook) &&
                    !(packet instanceof C06PacketPlayerPosLook)) {
                    event.cancel();
                }
            }
        }

        if (this.positionMode.getValue() && packet instanceof C03PacketPlayer) {
            const originalY = packet.getPositionY();
            packet.setPosition(packet.getPositionX(), originalY + 0.125, packet.getPositionZ());
        }

        if (this.placeMode.getValue() && packet instanceof C08PacketBlockPlacement) {
            event.cancel();
            const defaultBlockPos = new BlockPos(Number.NaN, Number.NaN, Number.NaN);
            const newPacket = new C08PacketBlockPlacement(
                defaultBlockPos,
                packet.getPlacedBlockDirection(),
                packet.getStack(),
                packet.getVec3()
            );
            breeze.sendPacket(newPacket, false);
        }

        if (this.karhu.getValue() && packet instanceof C03PacketPlayer) {
            this.lastOnGround = packet.onGround;
            event.cancel();
        }
    },

    packetReceive: function(event) {
        const packet = event.getPacket();
        const player = mc.getPlayer();

        if (this.ghostMode.getValue() && packet instanceof S08PacketPlayerPosLook) {
            event.cancel();
        }

        if (this.BlocksMCVelocity.getValue() && packet instanceof S12PacketEntityVelocity &&
            packet.getEntityID() === player.getEntityId()) {
            breeze.sendPacket(new C0BPacketEntityAction(player, "START_SNEAKING"), false);
            breeze.sendPacket(new C0BPacketEntityAction(player, "STOP_SNEAKING"), false);
        }
    },

    preMotion: function() {
        const player = mc.getPlayer();

        if (this.noSprint.getValue() && player.onGround()) {
            player.setSprinting(false);
        }
    }
});