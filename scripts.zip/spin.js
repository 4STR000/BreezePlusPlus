/*
name: Spin
author: Shoffli
*/

var yaw = 0;
var pitch = 0;

breeze.registerRotationModule('Spin', 'Makes you go round.', -100, {
    toggleYaw: new BooleanSetting('ToggleYaw', 'Enable or disable yaw rotation.', true),
    togglePitch: new BooleanSetting('TogglePitch', 'Enable or disable pitch rotation.', true),
    speedYaw: new DoubleSetting('SpeedYaw', 'The speed of the yaw rotation.', 50, 0, 150),
    speedPitch: new DoubleSetting('SpeedPitch', 'The speed of the pitch rotation.', 50, 0, 150),
    legit: new BooleanSetting('Legit', 'Makes you move legit.', false),
    
    enable: function() {
        yaw = mc.getPlayer().getYaw();
        pitch = mc.getPlayer().getPitch();
    },
    
    rotate: function(rotation) {
        rotation.setInstant(true);
        rotation.setLegitWalk(this.legit.getValue());

        if (this.toggleYaw.getValue()) {
            yaw += this.speedYaw.getValue();
        } else {
            yaw = mc.getPlayer().getYaw();
        }

        if (this.togglePitch.getValue()) {
            pitch += this.speedPitch.getValue();
        } else {
            pitch = mc.getPlayer().getPitch();
        }

        rotation.rotate(yaw, pitch, 0);
    }
});