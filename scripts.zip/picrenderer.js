/*
name: PicRenderer
author: Shoffli
*/

var killua = "https://iili.io/3rPsbus.png";
var astolfo = "https://iili.io/3rPsmwG.png";
var sonic = "https://iili.io/3rPLJP2.png";
var shrek = "https://iili.io/3rPsD9n.png";
var cock = "https://iili.io/3rPsZ8X.png";

breeze.registerHud('PicRenderer', 'This is why Breeze will always be better than Vape.', {

  mode: new ModeSetting('Mode', 'The mode to use.', 'Astolfo', ['Killua', 'Astolfo', 'Sonic', 'Shrek', 'Cock']),
  scale: new DoubleSetting('Scale', 'The scale of the image.', 0.6, 0.1, 2.0),

  settings: function() {
    return [this.mode, this.scale];
  },

  draw: function() {
    var selectedImage = null;

    if (this.mode.is('Killua')) {
      selectedImage = killua;
    } else if (this.mode.is('Astolfo')) {
      selectedImage = astolfo;
    } else if (this.mode.is('Sonic')) {
      selectedImage = sonic;
    } else if (this.mode.is('Shrek')) {
      selectedImage = shrek;
    } else if (this.mode.is('Cock')) {
      selectedImage = cock;
    }

    var fullWidth = mc.getDisplayWidth();
    var fullHeight = mc.getDisplayHeight();

    var scale = this.scale.getValue();
    var scaledWidth = fullWidth * scale;
    var scaledHeight = fullHeight * scale;

    var drawX = fullWidth - scaledWidth;
    var drawY = fullHeight - scaledHeight;

    if (selectedImage) {
      UIRenderer.remoteTexture(
        selectedImage,
        drawX, drawY,
        scaledWidth, scaledHeight,
        1, 10,
        new Color(255, 255, 255, 255)
      );
    }
  }
});