/*
name: ClientSpoofer
author: Shoffli
*/

const timer = new Timer();

breeze.registerModule('ClientSpoofer', 'Spoofs the client brand.', {

    brand: new StringSetting('Brand', 'The spoofed client brand.', 'Geyser', 32),

    packetSend: function(event) {
        const packet = event.getPacket();

            if (packet instanceof C17PacketCustomPayload) {
                event.cancel();

                const spoofedBrand = this.brand.getValue();
                const data = spoofedBrand;

                const spoofPacket = new C17PacketCustomPayload("MC|Brand", data, true);
                breeze.sendPacket(spoofPacket, false);
        }
    }

});