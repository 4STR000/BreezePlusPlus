/*
name: ResetVL
author: Shoffli
*/

var count = 0;

breeze.registerModule('ResetVL', 'Allows you to reset your violations.', {
    times: new IntSetting('Times', 'How often to perform the movement.', 50, 1, 50),
    timer: new DoubleSetting('Timer', 'How fast the game runs.', 1.5, 0.1, 10),

    motion: function (event) {
        if (mc.getPlayer().onGround() && count < this.times.getValue()) {
            event.setY(0.1);
            count++;
        }
        if (count >= this.times.getValue()) {
            breeze.postNotification('ResetVL', 'Successfully reset violations');
            mc.setTimerSpeed(1);
            count = 0;
            breeze.getModule("ResetVL").disable();
        }
    },

    tick: function () {
        mc.setTimerSpeed(this.timer.getValue());
    }
});