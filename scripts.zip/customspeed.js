/*
name: CustomSpeed
author: Shoffli
*/

const w = new KeyBind(gameSettings.keyBindForward());
const a = new KeyBind(gameSettings.keyBindLeft());
const s = new KeyBind(gameSettings.keyBindBack());
const d = new KeyBind(gameSettings.keyBindRight());

function degrees_to_radians(degrees) {
    return degrees * (Math.PI / 180);
}

breeze.registerRotationModule('CustomSpeed', 'A customisable speed.', -50, {
    modeType: new ModeSetting('ModeType', 'How to apply speed.', 'Motion', ['Motion', 'Friction']),
    applyMode: new ModeSetting('ApplyMode', 'When to apply the speed.', 'Both', ['Both', 'Ground', 'Air', 'Fall', 'Rise']),
    speed: new DoubleSetting('Speed', 'The speed used.', 1, 0.1, 20),
    frictionMultiplier: new DoubleSetting('Multiplier', 'The number your friction is multiplied with.', 1.0, 0.1, 5.0),
    jump: new BooleanSetting('Jump','Jumps when on ground.', true),
    groundStuck: new BooleanSetting('GroundStuck', 'Stucks horizontally on ground.', false),
    airStuck: new BooleanSetting('AirStuck', 'Stucks horizontally mid air.', false),
    lowHop: new BooleanSetting('LowHop', 'Works on NCP, Verus and more.', false),
    rotation: new BooleanSetting('Rotation', 'Aims into the move direction to bypass AntiCheats.', false),

    enable: function () {
        const player = mc.getPlayer();
        if (player) {
            this.yaw = player.getYaw();
        }
    },

    preMotion: function(event) {
        if (!this.modeType.is('Friction') || mc.isGuiOpen()) return;

        const player = mc.getPlayer();
        if (!player) return;

        const isOnGround = player.onGround();
        const verticalMotion = player.getMotionY();
        const isFalling = verticalMotion < 0;
        const isRising = verticalMotion > 0;

        const shouldApplySpeed = 
            (this.applyMode.is('Both')) || 
            (this.applyMode.is('Ground') && isOnGround) || 
            (this.applyMode.is('Air') && !isOnGround) || 
            (this.applyMode.is('Fall') && isFalling) || 
            (this.applyMode.is('Rise') && isRising);

        if (!shouldApplySpeed) return;

        const mult = this.frictionMultiplier.getValue();
        const currentFriction = event.getFriction();
        event.setFriction(currentFriction * mult);
    },

    motion: function(event) {
        if (!this.modeType.is('Motion') || mc.isGuiOpen()) return;

        const player = mc.getPlayer();
        if (!player) return;

        const isOnGround = player.onGround();
        const verticalMotion = player.getMotionY();
        const isFalling = verticalMotion < 0;
        const isRising = verticalMotion > 0;

        const shouldApplySpeed = 
            (this.applyMode.is('Both')) || 
            (this.applyMode.is('Ground') && isOnGround) || 
            (this.applyMode.is('Air') && !isOnGround) || 
            (this.applyMode.is('Fall') && isFalling) || 
            (this.applyMode.is('Rise') && isRising);

        if (!shouldApplySpeed) return;

        const speed = this.speed.getValue() * 0.2805;
        var yaw = player.getYaw();
        var fb = 0, strafe = 0;

        if (w.isDown()) fb += 1;
        if (s.isDown()) fb -= 1;
        if (a.isDown()) strafe -= 1;
        if (d.isDown()) strafe += 1;

        if (fb !== 0 || strafe !== 0) {
            if (fb === 1 && strafe === 0) yaw = yaw;
            if (fb === -1 && strafe === 0) yaw += 180;
            if (fb === 1 && strafe === 1) yaw += 45;
            if (fb === 1 && strafe === -1) yaw -= 45;
            if (fb === -1 && strafe === 1) yaw += 135;
            if (fb === -1 && strafe === -1) yaw -= 135;
            if (fb === 0 && strafe === 1) yaw += 90;
            if (fb === 0 && strafe === -1) yaw -= 90;

            const radYaw = degrees_to_radians(yaw);
            event.setX(-Math.sin(radYaw) * speed);
            event.setZ(Math.cos(radYaw) * speed);

            this.yaw = yaw % 360;
        }
        if (this.lowHop.getValue() && event.getY() > 0 && !isOnGround) {
            event.setY(-0.09800000190734863);
        }
        if (this.groundStuck.getValue() && isOnGround) {
            event.setX(0);
            event.setZ(0);
        }
        if (this.airStuck.getValue() && !isOnGround) {
            event.setX(0);
            event.setZ(0);
        }
    },

    rotate: function (rotation) {
        if (this.rotation.getValue() && this.modeType.is('Motion')) {
            const player = mc.getPlayer();
            if (player) {
                const targetYaw = this.yaw;
                const targetPitch = 0;
                rotation.setLegitWalk(true);
                rotation.setInstant(true);
                rotation.rotate(targetYaw, targetPitch, 0);
            }
        }
    },

    tick: function() {
        if (this.modeType.is('Friction')) {
            this.speed.setHidden(true);
            this.frictionMultiplier.setHidden(false);
            this.groundStuck.setHidden(true);
            this.airStuck.setHidden(true);
            this.lowHop.setHidden(true);
            this.rotation.setHidden(true);
        } else {
            this.speed.setHidden(false);
            this.frictionMultiplier.setHidden(true);
            this.groundStuck.setHidden(false);
            this.airStuck.setHidden(false);
            this.lowHop.setHidden(false);
            this.rotation.setHidden(false);
        }

        const player = mc.getPlayer();
        if (!player) return;

        if (this.jump.getValue() && player.onGround() && !mc.isGuiOpen() && (w.isDown() || a.isDown() || s.isDown() || d.isDown())) {
            player.jump();
        }
    }
});